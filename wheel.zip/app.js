function rotatewheel(){
    const wheel = document.querySelector('.wheel');
    const startButton = document.querySelector('.button');
    const wheelvalue = [500,400,900,0,600,700,800,-1,300,450,600,750,500,0,3000,
    600,700,350,500,800,300,400,650,1000]
    console.log(wheelvalue.indexOf(650))
    let deg = 0;


    startButton.addEventListener('click', () => {
        startButton.style.pointerEvents = 'auto';
        deg = Math.floor(2500 + Math.random() * 2500);
        console.log(deg)
        wheel.style.transition = 'all 5s ease-out';
        wheel.style.transform = `rotate(${deg}deg)`;
        wheel.classList.add('blur');
    });

     wheel.addEventListener('transitioned', () => {
     wheel.classList.remove('blur');
     startButton.style.pointerEvents = 'none';
     wheel.style.transition = 'none';
     const actualDeg = deg % 360;
     console.log(actualDeg);
     wheel.style.transform = `rotate(${actualDeg}deg)`;

    });
}
rotatewheel();